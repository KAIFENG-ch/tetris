/* 
 * File:        ui.h
 * Modified by: rsooio
 *
 * Modified on 19 Oct 2022, 22:44
 */

/***********USER FUNCTIONS***********

1.	AdcInit()
                - Must be called to initialise ADC.
                - Note what SFRs are effected and be sure not to overwrite these in yourt program initialisation.

2.	AdcVolt()
                - Call this to Clear LCD display

 */

#ifndef _UI__H_
#define _UI__H_

#include <xc.h>
#include "type.h"
#include "uart.h"
#include "pos.h"

//=============USER FUNCTIONS=============

void UIPageMain() {
    UartSendString("\f");
    UartSendUTF8(0xe2, 0x94, 0x8c);
    for (uint8_t i = 0; i < 64; i++) {
        UartSendUTF8(0xe2, 0x94, 0x80);
    }
    UartSendUTF8(0xe2, 0x94, 0x90);
    for (uint8_t i = 0; i < 20; i++) {
        UartSendString("\n\r");
        UartSendUTF8(0xe2, 0x94, 0x82);
        if (i == 5) {
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
            UartSendUTF8(0xe4, 0xbf, 0x84);
            UartSendChar(' ');
            UartSendUTF8(0xe7, 0xbd, 0x97);
            UartSendChar(' ');
            UartSendUTF8(0xe6, 0x96, 0xaf);
            UartSendChar(' ');
            UartSendUTF8(0xe6, 0x96, 0xb9);
            UartSendChar(' ');
            UartSendUTF8(0xe5, 0x9d, 0x97);
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
        } else if (i == 7) {
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
            UartSendUTF8(0xE6, 0xA2, 0x85);
            UartSendUTF8(0xE5, 0x8A, 0xAA);
            UartSendUTF8(0xE6, 0x96, 0xAF);
            UartSendUTF8(0xE7, 0x94, 0xB5);
            UartSendUTF8(0xE4, 0xBF, 0xA1);
            UartSendUTF8(0xE4, 0xB8, 0x89);
            UartSendUTF8(0xE7, 0x8F, 0xAD);
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
        } else if (i == 9) {
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
            UartSendUTF8(0xE5, 0xBC, 0xA0);
            UartSendUTF8(0xE9, 0x92, 0x8A);
            UartSendUTF8(0xE6, 0xB4, 0x8B);
            UartSendChar(' ');
            UartSendChar(' ');
            UartSendUTF8(0xE9, 0x99, 0x88);
            UartSendUTF8(0xE6, 0x81, 0xBA);
            UartSendUTF8(0xE4, 0xB8, 0xB0);
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
        } else if (i == 15) {
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
            UartSendUTF8(0xEF, 0xBC, 0x88);
            UartSendUTF8(0xE6, 0x8C, 0x89);
            UartSendUTF8(0xE4, 0xB8, 0x8B);
            UartSendUTF8(0xE5, 0x9B, 0x9E);
            UartSendUTF8(0xE8, 0xBD, 0xA6);
            UartSendUTF8(0xE9, 0x94, 0xAE);
            UartSendUTF8(0xEF, 0xBC, 0x89);
            for (uint8_t j = 0; j < 25; j++) UartSendChar(' ');
        } else {
            for (uint8_t j = 0; j < 64; j++) UartSendChar(' ');
        }
        UartSendUTF8(0xe2, 0x94, 0x82);
    }
    UartSendString("\n\r");
    UartSendUTF8(0xe2, 0x94, 0x94);
    for (uint8_t i = 0; i < 64; i++) {
        UartSendUTF8(0xe2, 0x94, 0x80);
    }
    UartSendUTF8(0xe2, 0x94, 0x98);
}

void UIPageMainToGame(pos *cursor) {
    PosMoveToNum(cursor, 43, 0);
    UartSendUTF8(0xE2, 0x94, 0xB4);
    for (uint8_t i = 0; i < 20; i++) {
        PosMove(cursor, -1, 1);
        UartSendUTF8(0xe2, 0x94, 0x82);
        cursor->x++;
    }
    PosMove(cursor, -1, 1);
    UartSendUTF8(0xe2, 0x94, 0xac);
    cursor->x+=2;
    PosMoveToNum(cursor, 22, 21);
    UartSendUTF8(0xe2, 0x94, 0xac);
    for (uint8_t i = 0; i < 20; i++) {
        PosMove(cursor, -1, -1);
        UartSendUTF8(0xe2, 0x94, 0x82);
        cursor->x++;
    }
    PosMove(cursor, -1, -1);
    UartSendUTF8(0xE2, 0x94, 0xB4);
    cursor->x+=2;
    PosMoveToNum(cursor, 0, 0);
}

//End ADC 8 Bit Interfacing Functions

#endif