/* 
 * File:        tetris.h
 * Modified by: rsooio
 *
 * Modified on 19 Oct 2022, 22:44
 */

/***********USER FUNCTIONS***********

1.	AdcInit()
                - Must be called to initialise ADC.
                - Note what SFRs are effected and be sure not to overwrite these in yourt program initialisation.

2.	AdcVolt()
                - Call this to Clear LCD display

 */

#ifndef _TETRIS__H_
#define _TETRIS__H_

#include "type.h"
#include "queue.h"

typedef struct Tetris {
    uint8_t *map, shape, shapeNext;
    int8_t x, y;
} tetris;

//=============USER FUNCTIONS=============

const uint16_t table[] = {
    0xd951, 0x4567, 0x26ae, 0xba98,
    0x6540, 0x9521, 0xa654, 0x9851,
    0x6542, 0xa951, 0x8654, 0x9510,
    0x5421, 0xa651, 0x9865, 0x9540,
    0x5410, 0x9652, 0xa954, 0x8541,
    0x6541, 0x9651, 0x9654, 0x9541,
    0xa965
};

uint8_t _randShape(queue* randset) {
    uint8_t shape = 0, rotate = 0;
    for (uint8_t i = 0; i < 3; i++) {
        shape |= (QueuePop(randset) << i);
    }
    for (uint8_t i = 0; i < 2; i++) {
        rotate |= (QueuePop(randset) << i);
    }
    return 4 * shape + rotate;
}

void _tetrisSwitch(tetris *t) {
    t->shape = t->shapeNext;
    t->x = 3;
    t->y = 0;
}

uint8_t _getBlock(tetris *t, uint8_t n) {
    return (t->map[n / 8] >> (n % 8)) & 1;
}

void _setBlock(tetris *t, uint8_t n, uint8_t v) {
    uint8_t num = t->map + n / 8;
    *num &= ~(0 << n % 8);
    *num |= ((v & 1) << n % 8);
}

tetris *TetrisInit(queue* randset) {
    uint8_t map[25] = {0};
    tetris t;
    t.map = map;
    t.shapeNext = _randShape(randset);
    _tetrisSwitch(&t);
    t.shapeNext = _randShape(randset);
    return &t;
}

void TetrisMove(tetris *t, uint8_t direction) {
    uint8_t x = t->x + (direction ? 1 : -1);
    for (uint8_t k = 0; k < 4; k++) { // block
        uint8_t pos = t->shape % (k * 16) / 16;
        uint8_t bx = x + pos % 4, by = t->y + pos / 4;
        if (bx < 0 || bx > 9 || by < 0 || by > 19) break;
        if (_getBlock(t, 10 * by + bx) != 0) break;
        if (k == 3) {
            t->x = x;
            return;
        }
    }
}

void TetrisRotate(tetris *t) {
    if (t->shape != 24) {
        uint16_t shapeRotate = t->shape;
        for (uint8_t i = 0; i < 3; i++) { // rotate
            shapeRotate += (shapeRotate % 4 == 3 ? 1 : -3);
            for (uint8_t j = 0; j < (t->shape < 4 ? 2 : 1); j++) { // move
                uint8_t x = t->x + j;
                for (uint8_t k = 0; k < 4; k++) { // block
                    uint8_t pos = shapeRotate % (k * 16) / 16;
                    uint8_t bx = x + pos % 4, by = t->y + pos / 4;
                    if (bx < 0 || bx > 9 || by < 0 || by > 19) break;
                    if (_getBlock(t, 10 * by + bx) != 0) break;
                    if (k == 3) {
                        t->shape = shapeRotate;
                        t->x = x;
                        return;
                    }
                }
                if (j != 0) {
                    uint8_t x = t->x - j;
                    for (uint8_t k = 0; k < 4; k++) { // block
                        uint8_t pos = shapeRotate % (k * 16) / 16;
                        uint8_t bx = x + pos % 4, by = t->y + pos / 4;
                        if (bx < 0 || bx > 9 || by < 0 || by > 19) break;
                        if (_getBlock(t, 10 * by + bx) != 0) break;
                        if (k == 3) {
                            t.shape = shapeRotate;
                            t->x = x;
                            return;
                        }
                    }
                }
            }
        }
    }
}

void TetrisNext(tetris *t) {
    uint8_t y = t->y + 1;
    for (uint8_t k = 0; k < 4; k++) { // block
        uint8_t pos = t->shape % (k * 16) / 16;
        uint8_t bx = t->x + pos % 4, by = y + pos / 4;
        if (bx < 0 || bx > 9 || by < 0 || by > 19) break;
        if (_getBlock(t, 10 * by + bx) != 0) break;
        if (k == 3) {
            t->y = y;
            return;
        }
    }
    for (uint8_t k = 0; k < 4; k++) { // block
        uint8_t pos = t->shape % (k * 16) / 16;
        uint8_t bx = t->x + pos % 4, by = t->y + pos / 4;
        _setBlock(t, 10 * by + bx, 1);
    }
}

//End ADC 8 Bit Interfacing Functions

#endif